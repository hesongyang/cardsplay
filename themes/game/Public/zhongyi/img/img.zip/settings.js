_CCSettings = {
    platform: "web-mobile",
    groupList: [
        "default"
    ],
    collisionMatrix: [
        [
            true
        ]
    ],
    rawAssets: {
        assets: {
            "0": [
                "resources/UI/card",
                1,
                1
            ],
            "1": [
                "resources/UI/card",
                1,
                1
            ],
            "2": [
                "resources/UI/card",
                1,
                1
            ],
            "3": [
                "resources/UI/card",
                1,
                1
            ],
            "4": [
                "resources/UI/card",
                1,
                1
            ],
            "5": [
                "resources/UI/card",
                1,
                1
            ],
            "6": [
                "resources/UI/card",
                1,
                1
            ],
            "7": [
                "resources/UI/card",
                1,
                1
            ],
            "8": [
                "resources/UI/card",
                1,
                1
            ],
            "9": [
                "resources/UI/card",
                1,
                1
            ],
            "10": [
                "resources/UI/card",
                1,
                1
            ],
            "11": [
                "resources/UI/card",
                1,
                1
            ],
            "12": [
                "resources/UI/card",
                1,
                1
            ],
            "13": [
                "resources/UI/card",
                1,
                1
            ],
            "14": [
                "resources/UI/card",
                1,
                1
            ],
            "15": [
                "resources/UI/card",
                1,
                1
            ],
            "16": [
                "resources/UI/card",
                1,
                1
            ],
            "17": [
                "resources/UI/card",
                1,
                1
            ],
            "18": [
                "resources/UI/card",
                1,
                1
            ],
            "19": [
                "resources/UI/card",
                1,
                1
            ],
            "20": [
                "resources/UI/card",
                1,
                1
            ],
            "21": [
                "resources/UI/card",
                1,
                1
            ],
            "22": [
                "resources/UI/card",
                1,
                1
            ],
            "23": [
                "resources/UI/card",
                1,
                1
            ],
            "24": [
                "resources/UI/card",
                1,
                1
            ],
            "25": [
                "resources/UI/card",
                1,
                1
            ],
            "26": [
                "resources/UI/card",
                1,
                1
            ],
            "27": [
                "resources/UI/card",
                1,
                1
            ],
            "28": [
                "resources/UI/card",
                1,
                1
            ],
            "29": [
                "resources/UI/card",
                1,
                1
            ],
            "30": [
                "resources/UI/card",
                1,
                1
            ],
            "31": [
                "resources/UI/card",
                1,
                1
            ],
            "32": [
                "resources/UI/card",
                1,
                1
            ],
            "33": [
                "resources/UI/card",
                1,
                1
            ],
            "34": [
                "resources/UI/card",
                1,
                1
            ],
            "35": [
                "resources/UI/card",
                1,
                1
            ],
            "36": [
                "resources/UI/card",
                1,
                1
            ],
            "37": [
                "resources/UI/card",
                1,
                1
            ],
            "38": [
                "resources/UI/card",
                1,
                1
            ],
            "39": [
                "resources/UI/card",
                1,
                1
            ],
            "40": [
                "resources/UI/card",
                1,
                1
            ],
            "41": [
                "resources/UI/card",
                1,
                1
            ],
            "42": [
                "resources/UI/card",
                1,
                1
            ],
            "43": [
                "resources/UI/card",
                1,
                1
            ],
            "44": [
                "resources/UI/card",
                1,
                1
            ],
            "45": [
                "resources/UI/card",
                1,
                1
            ],
            "46": [
                "resources/UI/card",
                1,
                1
            ],
            "47": [
                "resources/UI/card",
                1,
                1
            ],
            "48": [
                "resources/UI/card",
                1,
                1
            ],
            "49": [
                "resources/UI/card",
                1,
                1
            ],
            "50": [
                "resources/UI/card",
                1,
                1
            ],
            "51": [
                "resources/UI/card",
                1,
                1
            ],
            "52": [
                "resources/UI/card",
                1,
                1
            ],
            "53": [
                "resources/UI/card",
                1,
                1
            ],
            "54": [
                "resources/UI/card",
                1,
                1
            ],
            "55": [
                "resources/UI/card",
                1,
                1
            ],
            "56": [
                "resources/UI/card",
                1,
                1
            ],
            "57": [
                "resources/UI/card",
                1,
                1
            ],
            "58": [
                "resources/UI/card",
                1,
                1
            ],
            "59": [
                "resources/UI/card.plist",
                2
            ],
            "60": [
                "resources/UI/card",
                1,
                1
            ],
            "61": [
                "resources/UI/card",
                1,
                1
            ],
            "62": [
                "resources/UI/card",
                1,
                1
            ],
            "63": [
                "resources/UI/card",
                1,
                1
            ],
            "64": [
                "resources/UI/card",
                1,
                1
            ],
            "69": [
                "resources/UI/lk",
                1,
                1
            ],
            "70": [
                "resources/UI/lk",
                1,
                1
            ],
            "71": [
                "resources/UI/lk",
                1,
                1
            ],
            "72": [
                "resources/UI/lk",
                1,
                1
            ],
            "73": [
                "resources/UI/lk",
                1,
                1
            ],
            "74": [
                "resources/UI/lk",
                1,
                1
            ],
            "75": [
                "resources/UI/lk.plist",
                2
            ],
            "76": [
                "resources/UI/lk",
                1,
                1
            ],
            "77": [
                "resources/UI/lk",
                1,
                1
            ],
            "78": [
                "resources/UI/lk",
                1,
                1
            ],
            "79": [
                "resources/UI/lk",
                1,
                1
            ],
            "80": [
                "resources/UI/lk",
                1,
                1
            ],
            "81": [
                "resources/UI/lk",
                1,
                1
            ],
            "82": [
                "resources/UI/lk",
                1,
                1
            ],
            "83": [
                "resources/UI/lk",
                1,
                1
            ],
            "84": [
                "resources/UI/lk",
                1,
                1
            ],
            "85": [
                "resources/UI/lk",
                1,
                1
            ],
            "86": [
                "resources/UI/lk",
                1,
                1
            ],
            "87": [
                "resources/UI/lk",
                1,
                1
            ],
            "88": [
                "resources/UI/lk",
                1,
                1
            ],
            "89": [
                "resources/UI/lk",
                1,
                1
            ],
            "90": [
                "resources/UI/lk",
                1,
                1
            ],
            "91": [
                "resources/UI/lk",
                1,
                1
            ],
            "92": [
                "resources/UI/lk",
                1,
                1
            ],
            "93": [
                "resources/UI/lk",
                1,
                1
            ],
            "94": [
                "resources/UI/lk",
                1,
                1
            ],
            "95": [
                "resources/UI/lk",
                1,
                1
            ],
            "96": [
                "resources/prefab/SettingPanel.prefab",
                4
            ],
            "97": [
                "resources/UI/icon2",
                1,
                1
            ],
            "98": [
                "resources/UI/icon2",
                1,
                1
            ],
            "99": [
                "resources/UI/icon2",
                1,
                1
            ],
            "100": [
                "resources/prefab/history_sz.prefab",
                4
            ],
            "102": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "103": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "104": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "105": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "106": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "107": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "108": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "109": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "110": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "111": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "112": [
                "resources/UI/dianshu.plist",
                2
            ],
            "113": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "114": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "115": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "116": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "117": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "118": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "119": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "120": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "121": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "122": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "123": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "124": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "125": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "126": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "127": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "128": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "129": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "130": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "131": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "132": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "133": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "134": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "135": [
                "resources/UI/icon2",
                1,
                1
            ],
            "136": [
                "resources/UI/icon2",
                1,
                1
            ],
            "137": [
                "resources/UI/icon2",
                1,
                1
            ],
            "138": [
                "resources/UI/icon2.plist",
                2
            ],
            "139": [
                "resources/UI/icon2",
                1,
                1
            ],
            "140": [
                "resources/UI/icon2",
                1,
                1
            ],
            "141": [
                "resources/UI/icon2",
                1,
                1
            ],
            "142": [
                "resources/UI/icon2",
                1,
                1
            ],
            "143": [
                "resources/UI/icon2",
                1,
                1
            ],
            "144": [
                "resources/UI/icon2",
                1,
                1
            ],
            "145": [
                "resources/UI/icon2",
                1,
                1
            ],
            "146": [
                "resources/UI/icon2",
                1,
                1
            ],
            "147": [
                "resources/UI/icon2",
                1,
                1
            ],
            "148": [
                "resources/UI/icon2",
                1,
                1
            ],
            "149": [
                "resources/UI/icon2",
                1,
                1
            ],
            "150": [
                "resources/UI/icon2",
                1,
                1
            ],
            "151": [
                "resources/UI/icon2",
                1,
                1
            ],
            "152": [
                "resources/UI/icon2",
                1,
                1
            ],
            "153": [
                "resources/UI/icon2",
                1,
                1
            ],
            "154": [
                "resources/UI/icon2",
                1,
                1
            ],
            "155": [
                "resources/UI/icon2",
                1,
                1
            ],
            "156": [
                "resources/UI/icon2",
                1,
                1
            ],
            "157": [
                "resources/UI/icon2",
                1,
                1
            ],
            "158": [
                "resources/UI/icon2",
                1,
                1
            ],
            "159": [
                "resources/UI/icon2",
                1,
                1
            ],
            "160": [
                "resources/UI/icon2",
                1,
                1
            ],
            "171": [
                "resources/prefab/Liaotian.prefab",
                4
            ],
            "172": [
                "resources/UI/icon1",
                1,
                1
            ],
            "173": [
                "resources/UI/icon1",
                1,
                1
            ],
            "174": [
                "resources/UI/icon1",
                1,
                1
            ],
            "175": [
                "resources/UI/icon1",
                1,
                1
            ],
            "176": [
                "resources/UI/icon1.plist",
                2
            ],
            "177": [
                "resources/UI/icon1",
                1,
                1
            ],
            "178": [
                "resources/UI/icon1",
                1,
                1
            ],
            "179": [
                "resources/UI/icon1",
                1,
                1
            ],
            "180": [
                "resources/UI/icon1",
                1,
                1
            ],
            "181": [
                "resources/UI/icon1",
                1,
                1
            ],
            "182": [
                "resources/UI/ik2",
                1,
                1
            ],
            "183": [
                "resources/UI/ik2",
                1,
                1
            ],
            "184": [
                "resources/UI/ik2",
                1,
                1
            ],
            "185": [
                "resources/UI/ik2",
                1,
                1
            ],
            "186": [
                "resources/UI/ik2.plist",
                2
            ],
            "187": [
                "resources/UI/ik2",
                1,
                1
            ],
            "206": [
                "resources/prefab/fish.prefab",
                4
            ],
            "211": [
                "resources/Num/ta",
                1,
                1
            ],
            "238": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "239": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "240": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "241": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "242": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "243": [
                "resources/UI/paijiu_img.plist",
                2
            ],
            "244": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "245": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "246": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "247": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "248": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "249": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "250": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "251": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "252": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "253": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "254": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "255": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "256": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "257": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "258": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "259": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "260": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "f4s834NjlNMZy/CnkY/YqT": [
                "res/fish/Icon/fama_10_1.png",
                0
            ],
            "a5zDY3b/xBxY5qM46he0RS": [
                "res/fish/Icon/fama_1_1.png",
                0
            ],
            "9eZnODQoZF7ZI5+LE+dop0": [
                "res/fish/Icon/fama_20_1.png",
                0
            ],
            "c25VMTAppLpqGYjudaHj3H": [
                "res/fish/Icon/fama_2_1.png",
                0
            ],
            "60Qc4EDQRIvbq5y+aFm1ZO": [
                "res/fish/Icon/fama_3_1.png",
                0
            ],
            "97jIdGpLhARLQBCMt17T35": [
                "res/fish/Icon/fama_4_1.png",
                0
            ],
            "11ZQhH9LxINZR4T2oPtEYs": [
                "res/fish/Icon/fama_5_1.png",
                0
            ],
            "65LZ7qC5xDT5+xoOY7Zfqj": [
                "res/fish/Icon/fish_10.png",
                0
            ],
            "a5ZM2S/VJH+rKvONHvLOXV": [
                "res/fish/Icon/majiang.png",
                0
            ],
            "a9hlYSnUBHQamhCnyCyzwt": [
                "res/fish/Icon/paijiu_10.png",
                0
            ],
            "71dxquY45Aoa336R3WfCKA": [
                "res/fish/Icon/paijiu_6.png",
                0
            ],
            "038IzWPa1FKa/KAV/CnyKY": [
                "res/fish/Image 914.png",
                0
            ],
            "a8nSdqxF1MLKrsZuNWQcLs": [
                "res/fish/Image 916.png",
                0
            ],
            "0cdDnbSoRPvLjc2U8H9NP4": [
                "res/fish/Image 918.png",
                0
            ],
            "4fDxzPLMpFkZvwuneUOsnn": [
                "res/fish/Image 920.png",
                0
            ],
            "b4gtiU7IpLBqVDvpF7uV5t": [
                "res/fish/Image 922.png",
                0
            ],
            "15JfphRntC+4E5vU2RLgri": [
                "res/fish/Image 924.png",
                0
            ],
            fdNPOxKgNMQZPTGwaByPkR: [
                "res/fish/Image_x.png",
                0
            ],
            "47pN5LBxlAALOA4EhVWb9g": [
                "res/fish/ani/ani_1.png",
                0
            ],
            "71OfiCHe5EUoe4ogVPpo7y": [
                "res/fish/ani/ani_2.png",
                0
            ],
            "e18neySuNM5qTy4066v808": [
                "res/fish/ani/ani_3.png",
                0
            ],
            "8db+Wf12tOIIqlCS2Qj3ad": [
                "res/fish/ani/ani_4.png",
                0
            ],
            "81h9IG88BFuKJR7ErOjpbh": [
                "res/fish/comm_tips_bg.png",
                0
            ],
            "86qdvWhX9LkZeuekfWf2AN": [
                "res/fish/creat_bg.png",
                0
            ],
            "d3J162JMhDbZHSn5oOuAxF": [
                "res/fish/img_hulu.png",
                0
            ],
            "95G+cfky9Od5D/Y0KlFps5": [
                "res/fish/img_qian.png",
                0
            ],
            "49R5HyEIxBQ5Jr0gDZK9oc": [
                "res/fish/img_xia.png",
                0
            ],
            "b5EW+qyWZJFJ7MWwya4F0U": [
                "res/hall/hallbg.jpg",
                0
            ],
            "92126ojjtPGKF0SXaJ/Bdt": [
                "res/hall/lamplight_blue.png",
                0
            ],
            "19dPl1fXZAaJDqMXvroRrN": [
                "res/hall/lamplight_purple.png",
                0
            ],
            "060fxY97hPSrl0c3wQxFpw": [
                "res/hall/light_big.png",
                0
            ],
            "14VwkCg/JJdb2qGpzIFzwm": [
                "res/hall/light_micro.png",
                0
            ],
            "626lCZhd1C7r8vm3XLqIeY": [
                "res/hall/ting_bg2.jpg",
                0
            ],
            "24y2gjK8lGfogudDY8RY1h": [
                "res/normal/Num/DuiGuo.png",
                0
            ],
            "a2PDpHJzVNopBq2mJDkmoc": [
                "res/normal/Num/DuiKuang.png",
                0
            ],
            "54pTEKD29KVrsowqB49hqB": [
                "res/normal/Num/XuanDian.png",
                0
            ],
            "d14zRDwZdJZJirstAYt0Zx": [
                "res/normal/Num/alert.png",
                0
            ],
            "69Jxg+f1hFoYxAid7yFKfi": [
                "res/normal/Num/alert1.png",
                0
            ],
            "b8bQ00SBRH2r+4KQ66EF+o": [
                "res/normal/Num/avatar_head.png",
                0
            ],
            "a7COXNi9hGEJof8PzCrOV2": [
                "res/normal/Num/bg_input.png",
                0
            ],
            "b6ozJ0coBGDr9kq0PIdCuv": [
                "res/normal/Num/bg_red.jpg",
                0
            ],
            "21QKDmSYVLIb7584mQZJJa": [
                "res/normal/Num/bg_topline_phb.png",
                0
            ],
            "e2qraQYXpKrY4GPdvxstGl": [
                "res/normal/Num/bg_y.png",
                0
            ],
            "8eBRd0UldNWKjh8yGZcHfK": [
                "res/normal/Num/bp_jinkuang.png",
                0
            ],
            "8boPNT5O9P778K1luDIkO2": [
                "res/normal/Num/bp_jinkuang_3.png",
                0
            ],
            "2cb7OS6/dLqrwoQYaKt+ZE": [
                "res/normal/Num/btn_close.png",
                0
            ],
            "6fiWJvLwtPIZE+xP24+rZY": [
                "res/normal/Num/btn_game_home.png",
                0
            ],
            "e3DgKlbPpBv7NWaiHZHdQp": [
                "res/normal/Num/btn_home.png",
                0
            ],
            "ccQxz6io5JIYeX70BelG8N": [
                "res/normal/Num/btn_yan (1).png",
                0
            ],
            "47qq6ucVhM2JzB4e4C2L05": [
                "res/normal/Num/btn_yan.1.png",
                0
            ],
            "394FEsHvxIDIxJNLm0rBgR": [
                "res/normal/Num/bull_banker_animate.png",
                0
            ],
            "bcOkb/X8ZFA6PkwEkRCCTx": [
                "res/normal/Num/bull_banker_bg.png",
                0
            ],
            "8eR4c6bd9MzbLPUtwVhkyO": [
                "res/normal/Num/card_hand.png",
                0
            ],
            "1acfBnVTdPWqwP9tYXRo2q": [
                "res/normal/Num/card_hand_shadow.png",
                0
            ],
            "a4LVfcDapCVpSlQ1mdAbVH": [
                "res/normal/Num/chat_bg.png",
                0
            ],
            "dfPZ2AcwVPT4zquc6qQNxu": [
                "res/normal/Num/di.png",
                0
            ],
            "9fs1QtfVdDzbALMkXmumkv": [
                "res/normal/Num/dizhu_bg.png",
                0
            ],
            "02ucE8q6NO+KTq17+VdlCl": [
                "res/normal/Num/game-music01.png",
                0
            ],
            "3fY+JQrZBHjo33s3uKi64b": [
                "res/normal/Num/game_bg5.png",
                0
            ],
            "64HG0cNdZAu7y3wkWsSLrq": [
                "res/normal/Num/gb_btn.png",
                0
            ],
            "b5gZ7os4BLGZHHL4xwBJI1": [
                "res/normal/Num/goldcoin.png",
                0
            ],
            "5foY2Sh5VIabKv0pEAYzgh": [
                "res/normal/Num/grxx7_n.png",
                0
            ],
            "7292Js/01K96Cpy4TZYvKu": [
                "res/normal/Num/grxx7_n_1.png",
                0
            ],
            "9anXZpqSBJvbU1WqU6Qfjn": [
                "res/normal/Num/guize.png",
                0
            ],
            "35IA6ehGtIKYLAukAuYTg2": [
                "res/normal/Num/history2.png",
                0
            ],
            "c8cb5KTXtORLa8rtzwsE6w": [
                "res/normal/Num/hongbao1.png",
                0
            ],
            "914iUXyalA6LKfDQ0exBb7": [
                "res/normal/Num/inroom_btn.png",
                0
            ],
            "beLEW9nTZEE6Haxc0e8u0h": [
                "res/normal/Num/jiesuanbang.jpg",
                0
            ],
            "26PSGFh79A2apXh/Aa8V3U": [
                "res/normal/Num/line_11.jpg",
                0
            ],
            "bdpHOIv/ZEbb4hr/FbX6Lb": [
                "res/normal/Num/longhu13_n.png",
                0
            ],
            "4awCZvhIZCg6m7mWexb5nz": [
                "res/normal/Num/music_close.png",
                0
            ],
            "43Oo5+2jhCLIJs3cgvMebe": [
                "res/normal/Num/music_open.png",
                0
            ],
            "fe3Ejcx0BH77rYF7y5eIKa": [
                "res/normal/Num/niuniu_10.png",
                0
            ],
            "dcNXyYKnREApix/KJFkGS6": [
                "res/normal/Num/niuniu_6.png",
                0
            ],
            "a4lu/3RPBNubaH3l8PrJQj": [
                "res/normal/Num/pai_n.png",
                0
            ],
            "30xypsAXNNUZbYFJwkGEdI": [
                "res/normal/Num/ph_n.png",
                0
            ],
            "0cEQYTDgpB1bm7yGJulasZ": [
                "res/normal/Num/progress_bg.png",
                0
            ],
            "c8EpwzBUxG3bOqNiQSEexH": [
                "res/normal/Num/progress_con.png",
                0
            ],
            "3d8KDE2gpIQp2mY4eoKbw9": [
                "res/normal/Num/red_1.jpg",
                0
            ],
            "6feT/T1A5D7bOtE1fii3a8": [
                "res/normal/Num/room71_n.png",
                0
            ],
            "27u884uixF+5ciLNM+ZXAe": [
                "res/normal/Num/room72_s.png",
                0
            ],
            "f0Fl6k8Z1PS5RAM5qqRRuu": [
                "res/normal/Num/roomCard.png",
                0
            ],
            "30yIr+fENK97Tj7i8BP6rw": [
                "res/normal/Num/scj4_n.png",
                0
            ],
            "71KuHPM/FJublhksJgDN0P": [
                "res/normal/Num/shop_line.png",
                0
            ],
            "38nOa12p9FAYMA8KSDwxDH": [
                "res/normal/Num/single_white.png",
                0
            ],
            "01JAduFUFEOZplpo22jB8Y": [
                "res/normal/Num/sound_close.png",
                0
            ],
            "b5b2WttldNKphC4JmRMiZs": [
                "res/normal/Num/sound_open.png",
                0
            ],
            "ebzgKYyCBEdoJQZr9j/eqE": [
                "res/normal/Num/ting-card.png",
                0
            ],
            eeMVkGhAtAyIxHKjldqqIQ: [
                "res/normal/Num/ting-more.png",
                0
            ],
            "0c7gjW2V5Aa7a/gmcYng/j": [
                "res/normal/Num/xiaoxi.png",
                0
            ],
            "35U+fCcixJ3LNZ3w6k+A0/": [
                "res/normal/Num/xzzsxzjb.png",
                0
            ],
            "c4KqtOzs1KnJsWlVUXabAx": [
                "res/normal/Num/zhuang.png",
                0
            ],
            "c29mqNmQhC0raRE53dE/vg": [
                "res/normal/other/UI2.png",
                0
            ],
            "47efUPmR9Hpq1Yk9kHeNdm": [
                "res/normal/other/beimi-3.png",
                0
            ],
            "57Ol58XzJLbZVxbzLCMo91": [
                "res/paijiu/img_0.png",
                0
            ],
            "b8x2b/vaJH/Z6M8ejTgjjs": [
                "resources/Num/ta.png",
                0
            ],
            "fd09Pxe1ZKMZ3R4EA8vfaD": [
                "resources/UI/card",
                1,
                1
            ],
            "30uT4MSyhDGJT2ZqGuZvzW": [
                "resources/UI/card.png",
                0
            ],
            "d37eaaVB5Nf49Ubw1gQXUF": [
                "resources/UI/dianshu",
                1,
                1
            ],
            "70eKvuerpOF7kSvfMNW4pH": [
                "resources/UI/dianshu.png",
                0
            ],
            "7akUvw67lHP49OxXtxzP3n": [
                "resources/UI/icon1",
                1,
                1
            ],
            "52JDweCXBDfamt7m2Caj93": [
                "resources/UI/icon1.png",
                0
            ],
            "935bzNrMdE3p7Gl6Xcudwp": [
                "resources/UI/icon2",
                1,
                1
            ],
            "dadTCGQO9KtLQ6nWDU8+Yw": [
                "resources/UI/icon2.png",
                0
            ],
            "79jHCI5JhPwarxci/4PsI5": [
                "resources/UI/ik2",
                1,
                1
            ],
            "0790Bxm65EaL7QauE71Wnd": [
                "resources/UI/ik2.png",
                0
            ],
            "5elDW33j5NZor9ntBE1dup": [
                "resources/UI/lk",
                1,
                1
            ],
            "efr8DaekBOZKYM3UDrgDmy": [
                "resources/UI/lk.png",
                0
            ],
            "61RUnqNnBBO5K3UVEgYJt/": [
                "resources/UI/paijiu_img",
                1,
                1
            ],
            "94NaRLNFlNkLW8NOdh4H8W": [
                "resources/UI/paijiu_img.png",
                0
            ],
            "c7KJwJ7I5ClqlTqtnlujIk": [
                "resources/audios/bg/Audio_Magic_4.mp3",
                3
            ],
            "bb1SMsvYRKLr4Edtm84vOJ": [
                "resources/audios/bg/ReceiveGold1.mp3",
                3
            ],
            "8cllCOvmBDeJ/Z18DFU6aS": [
                "resources/audios/bg/Sound 137.mp3",
                3
            ],
            "69qfRnldpMVpSl51XS2WxB": [
                "resources/audios/bg/Sound 138.mp3",
                3
            ],
            "32MkMYVPJPdbY6Zp1AN7M2": [
                "resources/audios/bg/background.mp3",
                3
            ],
            "31KHzy/B5I9ZWz2og6bJIs": [
                "resources/audios/bg/backmusic.mp3",
                3
            ],
            "fb7c1cEqZGH4Otb+78GDHE": [
                "resources/audios/bg/bgMain.mp3",
                3
            ],
            "c6vgMqLEtOEYjtE5ecrZWw": [
                "resources/audios/bg/game_bg_rapid.mp3",
                3
            ],
            "ddU8YPEwpF+LAn1vHc+5FN": [
                "resources/audios/bg/jeton_sound.mp3",
                3
            ],
            "8fK2n0bQRGoIbfOuo9YwzF": [
                "resources/audios/bg/shake_dice.mp3",
                3
            ],
            "629SHF9AJGyaPSFgQMikl9": [
                "resources/audios/bg/spinbutton.mp3",
                3
            ],
            "bdbRhvzPBK66TtUpX7a3Io": [
                "resources/audios/bg/table_background_music.mp3",
                3
            ],
            "75HjSzGCxIAJRGUVMaVDdb": [
                "resources/audios/bg/wrslot_add_0.mp3",
                3
            ],
            "95+IlyxfJGlIKHsKUqg8M2": [
                "resources/audios/bg/wrslot_add_7.mp3",
                3
            ],
            "7cWBxb+ExNlKrJt4oCR8+h": [
                "resources/voice/man/dianshu_0_0.mp3",
                3
            ],
            "d6YftNGU1Idp6w1g2ewx+d": [
                "resources/voice/man/dianshu_0_1.mp3",
                3
            ],
            "93TMAP57VOq5rTGZdmJ0qA": [
                "resources/voice/man/dianshu_0_101.mp3",
                3
            ],
            "096BQ3Fe1EMYBg+CaEsWmo": [
                "resources/voice/man/dianshu_0_102.mp3",
                3
            ],
            "79ATK7pyRJHoFrKjoITdEQ": [
                "resources/voice/man/dianshu_0_103.mp3",
                3
            ],
            "4dqs/p4z1BiLNv9kUSMCTX": [
                "resources/voice/man/dianshu_0_104.mp3",
                3
            ],
            "67SqLKYeBNN5BTVbW37/sy": [
                "resources/voice/man/dianshu_0_105.mp3",
                3
            ],
            "51Fuz4gT9NbIOEb3q+8v8P": [
                "resources/voice/man/dianshu_0_106.mp3",
                3
            ],
            "bfhe6EIwRB7JWI/tu6U0fM": [
                "resources/voice/man/dianshu_0_107.mp3",
                3
            ],
            "5bQYtKW/dK/rRsj0qUWRIS": [
                "resources/voice/man/dianshu_0_108.mp3",
                3
            ],
            "11NLkW979Ol7tfzV9PhQyo": [
                "resources/voice/man/dianshu_0_109.mp3",
                3
            ],
            "b5F/JwlrdNI5obeKQ3AWut": [
                "resources/voice/man/dianshu_0_110.mp3",
                3
            ],
            "2czT4mumpBJLxGv8LnoyUz": [
                "resources/voice/man/dianshu_0_111.mp3",
                3
            ],
            "6d0Ngv1xNJTqCJsuegQ9oz": [
                "resources/voice/man/dianshu_0_112.mp3",
                3
            ],
            "a1NJy64sFKRrJw4v6C/WtJ": [
                "resources/voice/man/dianshu_0_113.mp3",
                3
            ],
            "3e6qpQ66JA47hAAM3i9c8T": [
                "resources/voice/man/dianshu_0_114.mp3",
                3
            ],
            "62yzdi/zdCn4b7xMgd+n3v": [
                "resources/voice/man/dianshu_0_115.mp3",
                3
            ],
            "0cAl/nmyNI/auAbLiYmjLX": [
                "resources/voice/man/dianshu_0_116.mp3",
                3
            ],
            "3a7WokZI5ORZsKW4/eadvO": [
                "resources/voice/man/dianshu_0_17.mp3",
                3
            ],
            "6178DPMENAt6xuTq9QXbNK": [
                "resources/voice/man/dianshu_0_2.mp3",
                3
            ],
            "7cIvG47bxCeLFScP6oUN6n": [
                "resources/voice/man/dianshu_0_27.mp3",
                3
            ],
            "cbLXUlxlFDZbIawo7tgv6z": [
                "resources/voice/man/dianshu_0_3.mp3",
                3
            ],
            "6aG9a18ZdPDbEwPnqc/D1L": [
                "resources/voice/man/dianshu_0_38.mp3",
                3
            ],
            "e7PbBUBblDsYLYmPRFF3Qb": [
                "resources/voice/man/dianshu_0_4.mp3",
                3
            ],
            "e6/kZWMzJIWbvI4iBtRE0J": [
                "resources/voice/man/dianshu_0_48.mp3",
                3
            ],
            "7dsVgazyxLp5izuIujObGA": [
                "resources/voice/man/dianshu_0_5.mp3",
                3
            ],
            "69F9e2fyxDZKrA/joV6UAl": [
                "resources/voice/man/dianshu_0_59.mp3",
                3
            ],
            "37ahoqRCtIw524iQ3Eyjk7": [
                "resources/voice/man/dianshu_0_6.mp3",
                3
            ],
            "a5DiDCStNLPqOdfslZOx3v": [
                "resources/voice/man/dianshu_0_69.mp3",
                3
            ],
            "9aQ7jIFsRNipCJ9cNHZPV8": [
                "resources/voice/man/dianshu_0_7.mp3",
                3
            ],
            "b8oXk2/nlEI5p24aC94ky7": [
                "resources/voice/man/dianshu_0_8.mp3",
                3
            ],
            "84OaapxdBJAI2yWa2D0BdG": [
                "resources/voice/man/dianshu_0_9.mp3",
                3
            ],
            "cbxKc0nbZAM7k/ioZDiw+o": [
                "resources/voice/man/fish_0_1.mp3",
                3
            ],
            "c9ix3UkCBPH6482CqFDy7r": [
                "resources/voice/man/fish_0_2.mp3",
                3
            ],
            "20vr7CWRZElbdYgK9VKiT0": [
                "resources/voice/man/fish_0_3.mp3",
                3
            ],
            "39Zr64XrhINqL7u7yxsxdV": [
                "resources/voice/man/fish_0_4.mp3",
                3
            ],
            "89bwms7StBsoBpFAeh6aBg": [
                "resources/voice/man/fish_0_5.mp3",
                3
            ],
            "d7s/0CJOZD4IFqVkN0TO1x": [
                "resources/voice/man/fish_0_6.mp3",
                3
            ],
            "57d/b6JYRFPKVWSJt6vSig": [
                "resources/voice/man/man_look_poper.mp3",
                3
            ],
            "d9azXtKOlJ2YnEEy9Kw+7P": [
                "resources/voice/man/message1_1.mp3",
                3
            ],
            "f4TeRYK75HlK/GXccZOLyO": [
                "resources/voice/man/message1_10.mp3",
                3
            ],
            "7f7p78OP5Lpb9/8p+q21Jj": [
                "resources/voice/man/message1_11.mp3",
                3
            ],
            "42Po7rESdHnpAYMbsjlGOE": [
                "resources/voice/man/message1_12.mp3",
                3
            ],
            "b276n5UmFCvbTH4Kv7r4b4": [
                "resources/voice/man/message1_13.mp3",
                3
            ],
            "c05SJATBJFPbNF/bRs6R0q": [
                "resources/voice/man/message1_2.mp3",
                3
            ],
            "fbTQdy1rhI3onkL2kw8h2F": [
                "resources/voice/man/message1_3.mp3",
                3
            ],
            "5bgUfl1StOKLipGFtV14Dw": [
                "resources/voice/man/message1_4.mp3",
                3
            ],
            "df2U1xEyFHB62+5JhhMVdT": [
                "resources/voice/man/message1_5.mp3",
                3
            ],
            "1a02hAKDVNhKV+xIFv0nsW": [
                "resources/voice/man/message1_6.mp3",
                3
            ],
            "14a+h3eV9J6KO77Bj5VtZh": [
                "resources/voice/man/message1_7.mp3",
                3
            ],
            "5bS5FnXzdHS4q3+NIOt/R6": [
                "resources/voice/man/message1_8.mp3",
                3
            ],
            "8cLYcxuhhBAbt0wHesY/H4": [
                "resources/voice/man/message1_9.mp3",
                3
            ],
            "e9B8x85xxMB4Au33j1n+VD": [
                "resources/voice/man/multiple1x1.mp3",
                3
            ],
            "ffcdpDrpRHMZxYf2dMEIIn": [
                "resources/voice/man/multiple1x10.mp3",
                3
            ],
            "577EfEeRNHnYexUiF9oAUF": [
                "resources/voice/man/multiple1x2.mp3",
                3
            ],
            "78iOwxbT9N+p/LuCCfgiLJ": [
                "resources/voice/man/multiple1x3.mp3",
                3
            ],
            "95AWjoND1PdK2k/QGHTWR/": [
                "resources/voice/man/multiple1x4.mp3",
                3
            ],
            "28AcgdYXhExoa7aS1v5tgT": [
                "resources/voice/man/multiple1x5.mp3",
                3
            ],
            "abqabts/JFxpYmWEod97Fy": [
                "resources/voice/man/niu1_0.mp3",
                3
            ],
            "11TTJCJFFLmbjd6GieT2k0": [
                "resources/voice/man/niu1_1.mp3",
                3
            ],
            "0f56BHvq9Ie5G4IRc5UTB+": [
                "resources/voice/man/niu1_10.mp3",
                3
            ],
            "f4H4xNhyhF9bRhMuIihcO+": [
                "resources/voice/man/niu1_11.mp3",
                3
            ],
            "e78C4sSvZL1KlGWaiveP8Z": [
                "resources/voice/man/niu1_12.mp3",
                3
            ],
            "8cpycrMlJH17plfiiIrEbE": [
                "resources/voice/man/niu1_13.mp3",
                3
            ],
            "72t3Rk7axErKhuqDk+I6q+": [
                "resources/voice/man/niu1_2.mp3",
                3
            ],
            "04GrHnJuZHJ4KRf6qZHVKM": [
                "resources/voice/man/niu1_3.mp3",
                3
            ],
            "0fS3cmsCdCTIlJgDMj+LLp": [
                "resources/voice/man/niu1_4.mp3",
                3
            ],
            "3el0b0SQ9NHp/knuYlimRy": [
                "resources/voice/man/niu1_5.mp3",
                3
            ],
            "1caTXMsl9C0aGyKnM+1utD": [
                "resources/voice/man/niu1_6.mp3",
                3
            ],
            "5coTSb8IZHKbtNb23Gb1Fs": [
                "resources/voice/man/niu1_7.mp3",
                3
            ],
            "76KMh0ANZGk4YHUcRonQvy": [
                "resources/voice/man/niu1_8.mp3",
                3
            ],
            "a1pXv6J55KWqthwkf1g6a6": [
                "resources/voice/man/niu1_9.mp3",
                3
            ],
            "fc2QebeDhGqakSbU+OmQK9": [
                "resources/voice/man/nobanker1_0.mp3",
                3
            ],
            "48ZZr3Q8tET47m9vbxTT7T": [
                "resources/voice/man/nobanker1_1.mp3",
                3
            ],
            "37zuj84PFIQKwcnJs4oME2": [
                "resources/voice/other/Sound 136.mp3",
                3
            ],
            "02LVmjSbdOb6nxVzgcWilW": [
                "resources/voice/other/Sound 139.mp3",
                3
            ],
            "1ew26chsdLh52AWp48cfPv": [
                "resources/voice/other/Sound 142.mp3",
                3
            ],
            "9423RyqXhEVpWyFoatHQ6a": [
                "resources/voice/other/fapai.mp3",
                3
            ],
            "83AOIiNeZOTbIqIRTylvjg": [
                "resources/voice/other/select.mp3",
                3
            ],
            "fd9irce6hI6J4JB3G15CkN": [
                "resources/voice/other/sort.mp3",
                3
            ],
            "3dKlkTYiNE7pts+wu0vIyG": [
                "resources/voice/woman/dianshu_0.mp3",
                3
            ],
            "c1CMLe1TpEU5yKYklis62Y": [
                "resources/voice/woman/dianshu_1.mp3",
                3
            ],
            "07DGizFCpMXpwfUdEp3BTB": [
                "resources/voice/woman/dianshu_101.mp3",
                3
            ],
            "d20NeDqCVFB6SCj0DcfbQj": [
                "resources/voice/woman/dianshu_102.mp3",
                3
            ],
            "61IghThVBMEpeB24OpLkvb": [
                "resources/voice/woman/dianshu_103.mp3",
                3
            ],
            "56S5IU3Q9DQpvvl4dtLqmQ": [
                "resources/voice/woman/dianshu_104.mp3",
                3
            ],
            "83LGXkKPdNOJVfs3TpKARw": [
                "resources/voice/woman/dianshu_105.mp3",
                3
            ],
            "2bu5uSc4JHX5IJTg/c/4T8": [
                "resources/voice/woman/dianshu_106.mp3",
                3
            ],
            "53mm5bGrNKs7CE+kepJiCE": [
                "resources/voice/woman/dianshu_107.mp3",
                3
            ],
            "cag9zbpHVI65df6/pXTveS": [
                "resources/voice/woman/dianshu_108.mp3",
                3
            ],
            "68WEvwhblPw6vvbCQp9UBS": [
                "resources/voice/woman/dianshu_109.mp3",
                3
            ],
            "f9R1kqX/1Gc7tjKU4AZWi1": [
                "resources/voice/woman/dianshu_110.mp3",
                3
            ],
            "f2m+EhLRlIwLvox9iZ1pO8": [
                "resources/voice/woman/dianshu_111.mp3",
                3
            ],
            "fb7U87sX5P5Z8GBGHtSMLN": [
                "resources/voice/woman/dianshu_112.mp3",
                3
            ],
            "95jMmyWwBF6YmSJpazQ054": [
                "resources/voice/woman/dianshu_113.mp3",
                3
            ],
            "0csjlE5qhEapJ3ZePmihJP": [
                "resources/voice/woman/dianshu_114.mp3",
                3
            ],
            "10pRMOzvBHeZqtCuQUSC9f": [
                "resources/voice/woman/dianshu_115.mp3",
                3
            ],
            "b3LXFUbVFIEppblIyZ+bJF": [
                "resources/voice/woman/dianshu_116.mp3",
                3
            ],
            "c0HcZdMuFM7oiex0raaosj": [
                "resources/voice/woman/dianshu_17.mp3",
                3
            ],
            "4c88xVBz1BhZn1a5yqFc4f": [
                "resources/voice/woman/dianshu_2.mp3",
                3
            ],
            "6cYfxY251MGKMZK4UEI1AD": [
                "resources/voice/woman/dianshu_27.mp3",
                3
            ],
            "e86AsknxNMtJWe7nhCaoko": [
                "resources/voice/woman/dianshu_3.mp3",
                3
            ],
            "83fOwhqD1NC6IT9xKh5cku": [
                "resources/voice/woman/dianshu_38.mp3",
                3
            ],
            "2aZFR1/QZCg67Y9CJXppGX": [
                "resources/voice/woman/dianshu_4.mp3",
                3
            ],
            "495qH6RR1CvbV0Z9l4gQPu": [
                "resources/voice/woman/dianshu_48.mp3",
                3
            ],
            "35Ri6w/sNM0bQYZOl8UdIU": [
                "resources/voice/woman/dianshu_5.mp3",
                3
            ],
            "a7HS9kzQ9BJqEBSlTvycM3": [
                "resources/voice/woman/dianshu_59.mp3",
                3
            ],
            "8cU13KfyVDoaVZC+DKuTpA": [
                "resources/voice/woman/dianshu_6.mp3",
                3
            ],
            "60e2KKL99HZKesdZAAJQwu": [
                "resources/voice/woman/dianshu_69.mp3",
                3
            ],
            "024O0RjihBka+CrhIVjbp3": [
                "resources/voice/woman/dianshu_7.mp3",
                3
            ],
            "136cKPqjNPm4RaMK+EtU/X": [
                "resources/voice/woman/dianshu_8.mp3",
                3
            ],
            "03b3AegU5DY78OxC8Ajk7w": [
                "resources/voice/woman/dianshu_9.mp3",
                3
            ],
            "6dCs2U43tHEZ0zBJRjVj6X": [
                "resources/voice/woman/fish_1.mp3",
                3
            ],
            "ffv/d4a4FL5J/LGu09IxNe": [
                "resources/voice/woman/fish_2.mp3",
                3
            ],
            "d5p88Yw+NLMLMjv74rTmjs": [
                "resources/voice/woman/fish_3.mp3",
                3
            ],
            "e0BrVoTHJAGrZXmt5+4OPs": [
                "resources/voice/woman/fish_4.mp3",
                3
            ],
            "01vrVX30xCPaoK9ox2xC+A": [
                "resources/voice/woman/fish_5.mp3",
                3
            ],
            "592jTAI8lExqjbzL56JQvi": [
                "resources/voice/woman/fish_6.mp3",
                3
            ],
            "9aQb0VVMZDPKPwlFEtIhq/": [
                "resources/voice/woman/message2_1.mp3",
                3
            ],
            "24+vetf+ND657udNv7rGI5": [
                "resources/voice/woman/message2_10.mp3",
                3
            ],
            "afS+89Fp5MDJ/XLXy+h53m": [
                "resources/voice/woman/message2_11.mp3",
                3
            ],
            "c2rrzb5gtB27RJYLvNgr9q": [
                "resources/voice/woman/message2_12.mp3",
                3
            ],
            "1e9jbrNQxP+q70tPe8E36V": [
                "resources/voice/woman/message2_13.mp3",
                3
            ],
            "e1iPqF6SFAuKcZ/8MG7kxp": [
                "resources/voice/woman/message2_2.mp3",
                3
            ],
            "d9QYj2LTNA7pVTB/B5TPrF": [
                "resources/voice/woman/message2_3.mp3",
                3
            ],
            "8cdXujDbJLaKhIjOmK4qv4": [
                "resources/voice/woman/message2_4.mp3",
                3
            ],
            "bdcArDQzxCRJkOCC90gX0l": [
                "resources/voice/woman/message2_5.mp3",
                3
            ],
            "5fBECYF6NJ7q6rbQsBIvtt": [
                "resources/voice/woman/message2_6.mp3",
                3
            ],
            "a9ky7e9VFOMoNXxQsbNN3V": [
                "resources/voice/woman/message2_7.mp3",
                3
            ],
            "41m2Z0qftH3ZJ5Arow3XR/": [
                "resources/voice/woman/message2_8.mp3",
                3
            ],
            "35VOec4OdOcpjhPOZw1eKe": [
                "resources/voice/woman/message2_9.mp3",
                3
            ],
            "dfN+2I57lB2a5w2m2K3E2n": [
                "resources/voice/woman/multiple2x1.mp3",
                3
            ],
            "b8hqHHPFxB4I2wn9SGavZS": [
                "resources/voice/woman/multiple2x10.mp3",
                3
            ],
            "96CUbjyJVCiaxYdQ4u6d8u": [
                "resources/voice/woman/multiple2x2.mp3",
                3
            ],
            "c6J4931ONMILWPHcFuKbvv": [
                "resources/voice/woman/multiple2x3.mp3",
                3
            ],
            "0dvf2obEJLOYx2T2hWwX00": [
                "resources/voice/woman/multiple2x4.mp3",
                3
            ],
            "ebxizqjTJFAopMLzf37e0Q": [
                "resources/voice/woman/multiple2x5.mp3",
                3
            ],
            "77MD50k2VFQYlufxUOWgoZ": [
                "resources/voice/woman/niu2_0.mp3",
                3
            ],
            "89MGmSrHdBYZmWh2GBdnGg": [
                "resources/voice/woman/niu2_1.mp3",
                3
            ],
            "e2hiZ5MoZOuLDTUwW63Ixp": [
                "resources/voice/woman/niu2_10.mp3",
                3
            ],
            "78AddEE+tHlp80XihLmDnd": [
                "resources/voice/woman/niu2_11.mp3",
                3
            ],
            "77P5Kug85Kw5VnkGCOWpeY": [
                "resources/voice/woman/niu2_12.mp3",
                3
            ],
            "a7s4VLkZ5I8IdLR7qT2+HC": [
                "resources/voice/woman/niu2_13.mp3",
                3
            ],
            "0fuRCmn61JF7sVMfuPY99T": [
                "resources/voice/woman/niu2_2.mp3",
                3
            ],
            "7dNKDjC8xCiK/Fc/PBeRcP": [
                "resources/voice/woman/niu2_3.mp3",
                3
            ],
            "4cWg3HXuJFQLQUkFwUB8cD": [
                "resources/voice/woman/niu2_4.mp3",
                3
            ],
            "d6963NUMVJ9KNQDmpfmUEK": [
                "resources/voice/woman/niu2_5.mp3",
                3
            ],
            "ae7N/UUXFE0Y/sDVhCzch/": [
                "resources/voice/woman/niu2_6.mp3",
                3
            ],
            "cabUA2iHZNQaD2az3m9G5u": [
                "resources/voice/woman/niu2_7.mp3",
                3
            ],
            "e6v5V+x29OUbwfy9T879FN": [
                "resources/voice/woman/niu2_8.mp3",
                3
            ],
            "7cIdyTcrdN5oP2S5R/SSGS": [
                "resources/voice/woman/niu2_9.mp3",
                3
            ],
            "84Xhl51plB3ppTYDqbBqJl": [
                "resources/voice/woman/nobanker2_0.mp3",
                3
            ],
            "62K75KqNZEg6z+GbAvDsDp": [
                "resources/voice/woman/nobanker2_1.mp3",
                3
            ],
            "98oPLapz1H94/p9SbwS4C/": [
                "resources/voice/woman/woman_look_poper.mp3",
                3
            ]
        },
        internal: {
            "d8HsitJHxOYqo801xBk8ev": [
                "image/default_panel.png",
                0
            ],
            "cf73jxyN9Jt47QTJU6ziYh": [
                "image/default_progressbar.png",
                0
            ],
            "4bq2fLGOZAmbhANV8Ec/iQ": [
                "image/default_scrollbar_bg.png",
                0
            ],
            "d608qFRoFHwbXd0Dap056i": [
                "image/default_scrollbar_vertical.png",
                0
            ],
            "61cyPdEfRN047sDK9rO0W5": [
                "image/default_scrollbar_vertical_bg.png",
                0
            ],
            "02delMVqdBD70a/HSD99FK": [
                "image/default_sprite_splash.png",
                0
            ]
        }
    },
    assetTypes: [
        "cc.Texture2D",
        "cc.SpriteFrame",
        "cc.SpriteAtlas",
        "cc.AudioClip",
        "cc.Prefab"
    ],
    jsList: [
        "assets/scripts/Toast.4457f.js"
    ],
    launchScene: "db://assets/scenes/hall.fire",
    scenes: [
        {
            url: "db://assets/scenes/hall.fire",
            uuid: 165
        },
        {
            url: "db://assets/scenes/friendGroup.fire",
            uuid: 209
        },
        {
            url: "db://assets/scenes/game_fish.fire",
            uuid: 266
        },
        {
            url: "db://assets/scenes/game.fire",
            uuid: 199
        },
        {
            url: "db://assets/scenes/end.fire",
            uuid: 167
        },
        {
            url: "db://assets/scenes/receive.fire",
            uuid: 188
        },
        {
            url: "db://assets/scenes/redPacket.fire",
            uuid: 236
        },
        {
            url: "db://assets/scenes/sendCard.fire",
            uuid: 65
        },
        {
            url: "db://assets/scenes/sixgame.fire",
            uuid: 68
        },
        {
            url: "db://assets/scenes/standings_1.fire",
            uuid: 232
        },
        {
            url: "db://assets/scenes/standings.fire",
            uuid: 233
        }
    ],
    packedAssets: {
        "01253e92": [
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            24,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            33,
            34,
            35,
            36,
            37,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            46,
            47,
            48,
            49,
            50,
            51,
            52,
            53,
            54,
            55,
            56,
            57,
            58,
            59,
            60,
            61,
            62,
            63,
            64
        ],
        "022f62f27": [
            219,
            66,
            67,
            65
        ],
        "026e49340": [
            191,
            161,
            192,
            162,
            193,
            194,
            163,
            195,
            66,
            196,
            197,
            198,
            200,
            67,
            201,
            68,
            202,
            203,
            204,
            170,
            205
        ],
        "02bbe3181": [
            69,
            70,
            71,
            72,
            73,
            74,
            75,
            76,
            77,
            78,
            79,
            80,
            81,
            82,
            83,
            84,
            85,
            86,
            87,
            88,
            89,
            90,
            91,
            92,
            93,
            94,
            95
        ],
        "03e47ed6": [
            "06pmLFF+5Id5mZ8SLH0D79",
            96,
            "0d+Z6Spp5PV7irPlkqp0bA",
            "1aVKmTyEtGEY92OZvDS5W8",
            "44nXzjoT1MA6Gz//rC4ZgT",
            "75Qzcor81AcrnLp4FK7ghS",
            164,
            166,
            "b5PMGYVpdPBrxBu5e25Yru",
            "dcPQI8gTpFXoOpgRXRS3aN",
            "f7exq2nVlCspH6IT9XW1b+",
            101
        ],
        "044738c47": [
            97,
            98,
            "7c6Y/c5RlDSqNTKDja65WB",
            99,
            67,
            100,
            269,
            270,
            101
        ],
        "04515c98e": [
            102,
            103,
            104,
            105,
            106,
            107,
            108,
            109,
            110,
            111,
            112,
            113,
            114,
            115,
            116,
            117,
            118,
            119,
            120,
            121,
            122,
            123,
            124,
            125,
            126,
            127,
            128,
            129,
            130,
            131,
            132,
            133,
            134
        ],
        "05670e58a": [
            "75K6BdoetKkYhVqXGslfZe",
            "7c9lDRPVtKhJ01eRRod0KU",
            "a9pgiNzjtHT7eBpbouyFj3",
            101
        ],
        "064f848f2": [
            135,
            136,
            137,
            138,
            139,
            140,
            141,
            142,
            143,
            144,
            145,
            146,
            97,
            147,
            98,
            148,
            149,
            150,
            99,
            151,
            152,
            153,
            154,
            155,
            156,
            157,
            158,
            159,
            160
        ],
        "067c3fa18": [
            "015ZuioW9IRIPeS7d+lijk",
            161,
            207,
            162,
            "32Yyl00vRPhr+DMqNlmBVI",
            "34mCZCLIxLAZMsdHiybH17",
            "35oKGr6HpN9KFR58lYSwl8",
            "3dRiKmxlpEOLE3f6m7K6xk",
            "3dU+VVLIFMdpJ4c9wsfAw+",
            "40rG6m7kpLIoToej4lVwrK",
            "43trva0u5EC40cUHmAdFeX",
            "436UHBKRhMWb9wNm5MZZwR",
            "46jabuaSZH37x2QwmWoSG1",
            "4a2BHN7g1P4riRcFxgXlzz",
            163,
            220,
            66,
            168,
            222,
            169,
            "63R9/AZEVLRIxt8Vl1W4Kv",
            "63r64o5AFLpL3aXJPcM06Q",
            225,
            "675ovJ2tVK2aLYfgPUWOMv",
            208,
            189,
            210,
            164,
            67,
            "a55MBFrthEOZgnddOPyT0W",
            "b1n1CDWF1CkIshuKcjsmvA",
            228,
            165,
            "c9+lH/PwFGAY+AMl0bEdq3",
            "d2sQOkjElF+KdpDDIOJdfZ",
            "d5sGTz3TxDxK0k26WwCXXZ",
            "e9UADxIdpEaLv4dqZfFsBf",
            "edUcneXFdKorBwEHtBsvvU"
        ],
        "07617dde3": [
            "1eibZ8zzdM7aQ+gtJsR97t",
            231,
            "50IUS5vu1Gc7zx2wJAWXYK",
            "84VN0ndUhAiY7AlgTVzcjd",
            "983iSExStPh567OZ4K6JFO",
            67,
            "a6eLJCfSBLQb0NaeRSvAI2",
            166,
            "d2lnd7Us5P2LoKwhlp5fto",
            "d9p+kByxhICqyX2iPZ6QuF",
            "e6q54qYSVHL6y6Gu0v9CJT",
            190,
            101
        ],
        "08c86ade3": [
            167,
            "32yHnkAt5Ia6YAlpdhdacb",
            216,
            217,
            163,
            168,
            169,
            "6eFV46gZpC3JPwrEz5gjCC",
            226,
            170
        ],
        "08d24b90b": [
            "27kWvLmd9HI6/jhAsq6MjN",
            "4e6Ra6mAdP8LqR5bjHdD8O",
            168,
            169,
            224,
            67,
            171
        ],
        "091128195": [
            172,
            173,
            174,
            175,
            176,
            177,
            178,
            179,
            180,
            181
        ],
        "091fe0a1c": [
            "a3rXNHVzxDk75ax+L+q2Ny",
            181
        ],
        "09ba18894": [
            182,
            183,
            184,
            185,
            186,
            187
        ],
        "09f78cad8": [
            "a8ELr0YyJNPIGBOKChxk5S",
            122
        ],
        "0a6bb64f3": [
            "1dNwU156dMso7VmeZq8M8u",
            "27nwmwC61OSqOull0uxpli",
            "28YzLPLidB8KfOvBbmthQE",
            "45+PCXcH1N3LuA4gD6+A+A",
            163,
            "50Q6TuUEdMyLDFW/BphMFv",
            188,
            "5c+8tJH59Ma62aRaFEh3+u",
            "65DwPL7d5JXJpW2sBOKnEz",
            212,
            "6f7mmGvqhC2YX1nck+OCVb",
            "71QCxESVVKR6a85XutL2qK",
            "74k/N6s6FD3obolwWD61Ij",
            "7aor2AxP1FCoK+AoX2QLDJ",
            189,
            "99eeGZOLtCPKKp0hq4Q0vl",
            67,
            "e4mVCCqF1In5cVVXBm4ak1",
            "e5SMa6lJNMFrVVb3oBOBxv",
            190,
            237
        ],
        "0b78af307": [
            191,
            161,
            261,
            192,
            162,
            193,
            263,
            194,
            163,
            195,
            66,
            265,
            196,
            197,
            198,
            199,
            200,
            67,
            201,
            202,
            203,
            271,
            273,
            204,
            276,
            277,
            170,
            205,
            280,
            281
        ],
        "0c837bb54": [
            "35b3EB45hNQ4Oxqgdn+hyG",
            "9eXdC3LbBA1bWnHFJ0L6cE"
        ],
        "0d00493e3": [
            262,
            "20NCwN2uREqamPCiwBBqUb",
            137,
            140,
            141,
            143,
            144,
            264,
            147,
            148,
            149,
            150,
            206,
            "8bBbcMCwxGj5EEnMc1bCrP",
            "8eCRnEPn5Db79TzKWmnPOv",
            67,
            267,
            268,
            152,
            "bdowQlDXpPSrC9SaKxbGjm",
            272,
            274,
            "e1R6Y5IbBOLJSrqyzvpuko",
            275,
            157,
            158,
            160,
            278,
            "f1ytZtcAJIOIC4EWbJ1f++",
            279,
            "fcD/PPSjtOva/YjoSzhHKI"
        ],
        "0d7da1969": [
            "1cpS+PCnpCD5JHc+MYeyqO",
            207,
            163,
            168,
            169,
            208,
            196,
            209,
            210,
            67,
            201,
            204,
            190
        ],
        "0d88271f5": [
            211,
            213,
            214,
            "0cJo6X3K1EWYQtOiACcLZD",
            "1eE+Ce1SZGD49JkI+4iFK8",
            "1eW7GuCRRBHJQyUv/ftzpA",
            "2aHczKYcVHo7Uv/bdH4oOq",
            215,
            "42ImD9a45NMpfVazvMnZ7z",
            218,
            163,
            "4ekoZAmvFByKtZSrKGEy/h",
            "52pZ3k6ZJJDZJ0xiFm/MVm",
            66,
            "59q0QLeWZI56h/3c58tLsH",
            221,
            223,
            "68fpFULJVM9q+6+RqAjeSH",
            "6aQbdBIw5PTICY3FchnESS",
            212,
            "6czc/tPPlDMrYuBWXvwuqT",
            "78lr6fbNVJeKpMPSkDq1Pn",
            "7bz9Qu6XVHvp1zTzzqwz75",
            "83N17dPiZFxrS3BJwx3OsI",
            "89lKd2+yBFFbZ0mTzaW+Ti",
            210,
            "8cMoBrT75FM5ZJxk1NbJYO",
            "93Gfy35mpP/qC3TGBNQDbw",
            "95xoMP5oBM3Z+yK4+fE4cI",
            "99zhQ7YfJNxovxqcOl+WdL",
            227,
            "9fd22nRXdLsq+T60Yk+MPp",
            67,
            "a6a7FzqbBHjqCSYzreyoeL",
            "a8oRiM15lGD4i/dAbejF3L",
            "b7z5xUUL9AT6P8/D5jIzIT",
            229,
            "c1DSEe5FhNTqzqqLnIzAPT",
            "daToRDgpJITIrq6pPJdjHS",
            230,
            "eaexmGZL5AyJ8UsvXdkHjB",
            "efQqq3QEhMG5BnJbfuG0F8",
            "f7hNqv7mBDibKvmHACkVRt",
            "f8H71+GfFMjIUGSnowrpCu",
            "f84uLirPZJeaPHbYirgicq"
        ],
        "0db5f6eb3": [
            213,
            214,
            "09KkSFaGdOTrTJLjB9zoA3",
            "18QYWZOxJBM7naVR0Ina4T",
            192,
            "20EVJtSbJOqKSdeBIOhzbQ",
            "21B160CNRM44IQGc0ZA809",
            193,
            215,
            216,
            "38sgOwLDNLWavpcLTx3znc",
            "4cTDAK2rtC25GIRHIH2Cft",
            217,
            218,
            163,
            219,
            "56AJqUldROT7irklw4GjxE",
            220,
            66,
            221,
            222,
            223,
            "62s8PXuD5Mb54wV7fobDCE",
            "6354qEW8NM0aZ7e8zcmnEi",
            224,
            225,
            212,
            "73mdoonLBCnKtNbiOriBER",
            "7cHmgJiXhOoJHxXGzx8ONs",
            196,
            226,
            227,
            200,
            201,
            "a6kB4hT+ZNN6zUkid57de/",
            228,
            229,
            "c2djS+De9PFKExUOr+NvOR",
            "cdPE/5KJZOY5Ihk0nsYVYf",
            "d13JCP4kFBCruTgAd1PuMm",
            "d9Fz8Ly+dHq5Zu3GU3eyYz",
            "e54OjQH7dCZI5wxyx5M6Jw",
            230,
            "ea7kzbW99ENbOFvZgnSkoG",
            "ee0NrmJFlO7bUfnWSG9PxH",
            "f0KH+9BgNEmYC3OYDfn7uG",
            "f0OMxgfABJjZe8p6ZCDRZy",
            205
        ],
        "0e5d7cbf3": [
            231,
            232,
            163,
            219,
            168,
            169,
            "73UtuXC5xMK4qL/t96uO1A",
            "91h1vCXuhOJ5j+zUklmq4f",
            "97Te094c1E2q/T5C4591QV",
            234,
            "a09Ca4xNhOL6TDaWgUYzJK",
            67,
            "b4+Hz5GBNA+5G1rJI0d9iI",
            "c712aU7MtIU6XK7ti/WrV6",
            190,
            235,
            101
        ],
        "0e6d2fc24": [
            "0eDFMYanZPmLYj6qBx8O48",
            233,
            163,
            219,
            168,
            169,
            234,
            67,
            190,
            235
        ],
        "0eacd064e": [
            163,
            168,
            169,
            236,
            67,
            204,
            190,
            237,
            "f5ptgO9FBABIHLaFRo6bYR"
        ],
        "0f281f1f9": [
            238,
            239,
            240,
            241,
            242,
            243,
            244,
            245,
            246,
            247,
            248,
            249,
            250,
            251,
            252,
            253,
            254,
            255,
            256,
            257,
            258,
            259,
            260
        ],
        "0fbd1a5b5": [
            191,
            161,
            261,
            262,
            192,
            162,
            193,
            137,
            140,
            141,
            263,
            194,
            163,
            143,
            195,
            66,
            144,
            264,
            97,
            147,
            98,
            265,
            148,
            196,
            197,
            149,
            150,
            266,
            198,
            99,
            200,
            67,
            201,
            267,
            268,
            152,
            269,
            202,
            270,
            203,
            271,
            272,
            273,
            274,
            204,
            275,
            276,
            157,
            158,
            277,
            170,
            160,
            278,
            205,
            279,
            280,
            281
        ]
    },
    orientation: "portrait",
    uuids: [
        "0fEtnlZsVHlINVeGUjzW6L",
        "0f7ud9CQVJaZCMq8quNN4K",
        "10SI1LzrRAN6EE2PHSVS/H",
        "128jEKDJ1OHpDDQPf3XscW",
        "17KOUCR8JPEI1QQS5+5ILh",
        "1cMEu3cGJMyLlBJ+Mn8vrU",
        "1dcZJ/dHdJoKRUiUyzo9cK",
        "2472+zXlFLJbx9o2ld4qGM",
        "33WBMuVWdN3LipgdOHgB24",
        "33uzyPlVhFvKiRPCA7w3b7",
        "343H74YV5MpL6YkdBZN9V2",
        "35Rpln+9ZMSZ8zuq7lO9KZ",
        "36orsIfLtELbTWF7kC9GMv",
        "38E6oVTpFBp4f9vE2UAQTn",
        "39vRZZ82lE+KfOyuF9OpSH",
        "395PwMuGZCqbFWRv99MrWD",
        "3asERO9ORJgZABFtSqyG3h",
        "3a+YGgOgBG0as/vfukT7oE",
        "3byXYaEQ5EAIqonS48Tkrs",
        "41S7X0xAxMC6QLDPEiXPOQ",
        "43ZCVSFDFNnbBHne+K6Yms",
        "47kxXWJRZPE5o/mKQmLA7Z",
        "4cVxAOJDhD4KHDAAN9BQgB",
        "533dNOlKlPkZTf+mh/4IbH",
        "55947HF3lIprwm12oLgRW/",
        "57ZI9I8WlDgI/ZbKNxtclV",
        "5eHeH5ohdOkYAoZ+optZyL",
        "62H1NHh7NAkpm1w29esMon",
        "67gGtp7gZHUKTbsxS8PuLq",
        "6aKMkDP3NNr7K1U37VUaMJ",
        "6agFt2zMpGA4p3wOh6Bexc",
        "78MsmFtUtIdqyu3E8C8gse",
        "78SDtCpQRBBrauSrbQr0Ua",
        "7fYkO2jyROMJs8pbzPBxHj",
        "7fyP2JIx1LM6wdzE7kNslI",
        "8813xASJdHOZ5/iVQ3aSR8",
        "90S/mKdgZHa745/fb4yKvN",
        "970lDfFzRK6Lv7NFEAc/R6",
        "a6i9MeR6pHDKxvNJJusD4R",
        "aafSOYxhpDgL7eBHg7+/7J",
        "aeHCKJi/pKwa71xg2YY0Fu",
        "afGHS4HENCd4z6DLtzo1Fh",
        "afaeruCO5LLqqXQqysEjY2",
        "b00EucefhF8pYgLVYjJzkm",
        "b1U3vaecVFDJcPTS/Dl6Qi",
        "b1y8WwavRJEKPMSaTk37gm",
        "baRTWBGwxFLbKdKtZ2FgeZ",
        "bcUDCx26hDcpVZkcRTG82c",
        "c4ArO2CEpBSrKe5gkuOMDj",
        "c4H+d6jYFMUbZCnd0ydOqc",
        "c4wAxlvepLbLRsYiTDi9XY",
        "cbxSXzzXVAj56lbSNMKPgN",
        "cdv7UG4gZGcK5HMdk9Ojo7",
        "ceDRcMDHxBn4No9vN0mRkt",
        "d0yvLotBVNXagpTLmWlyan",
        "d166mlEKJKPaCZCPUvPHHu",
        "d5sZUZc6VEALVNVxE2dbAt",
        "d8xFoPCWhBH6NdlX+kOmoj",
        "e1gXVbzyRBCJWKkoTrSn32",
        "e5utkNaVVHoaIQk2nDvD0v",
        "ecNCcet5FHW5EX/bKMP/kq",
        "ee6pTGaLxAj5qLnh0v8Ria",
        "f5HU6nVRZM4IFvXpeZlBII",
        "f6/uvkDcxMUZC9K+zFTzN3",
        "fdZxx0hUBH4ph1wRrrGwMT",
        "e9Nzv93wZB+aGaAqmNcSZx",
        "59LVOgkC5KaY1b13dhMMx7",
        "a2MjXRFdtLlYQ5ouAFv/+R",
        "b8qxrFINpNe4shnIwYiJdn",
        "00LUacPA5IBoZzpk8dcvWV",
        "1dEb4dKqJG+IQtI0Mk/v/D",
        "1f18YTlLhLFp1gVRTOD5Yi",
        "3a4ubxufVBooVreahbobVm",
        "43HzfNyrhEt4MN8GJLR1z7",
        "54n+GwwjVGzpXL7gg6hoIS",
        "57jOO39hxFn4hZMd2Ro623",
        "5bHhOOK4VH/bf9hWLoKF7y",
        "701WHGAdFBv7K1cxJDOq+W",
        "73LK4Nl3VM+r8ULcI1gLRb",
        "78mnHeCVJCsZRVsAUYk+GH",
        "896uMyuNtAtpnQJUST4HVl",
        "a0Q54KzkxH+KnQtixwhGRN",
        "a15QG+jDtBtrUh/9i+bU8m",
        "aaqEqwQBNHZpT1AdEKyXJP",
        "acKKiAiPdNMpzX53jGMOKJ",
        "bbQyjQB2JKj74e0BrT6Mr6",
        "bbVN9ABFxNY4Sh/HooO8aj",
        "c9/ZaLq0VCw4NCTULArXIp",
        "cfZN9Qp3lE2bDVBPAAvwAI",
        "deLrbDjEZPDojU18IN9b1N",
        "ebwiTcBoxOlrx/V9Sd8KLH",
        "eevbtp87dEVpsiFwNwCCUt",
        "efaivhi1VBmqpYqduQ7bBn",
        "f5IO5j5hZJlp+lg1zuG0iV",
        "f6P6z5/INBIpjhor8k4EDx",
        "fbtEaTOkhAookZpR2G6FxP",
        "07CnOJ2OZLOYCeky7ow0uX",
        "697Vfs+TFKLKA3UyrKcRTV",
        "74z1SmlnxI4pbbChQabRLB",
        "92gfjWIrpCKarnZHIbWNvW",
        "b3zR4x5MlKZLA5eeoQ8lJ3",
        "f9OEYyWiRE9KUqsFmBkKBk",
        "19wND4ZIBLFKhWRmR2hnh+",
        "20YXgsnw1Py7OWaxXL7cJ/",
        "28LFSt4ORO+5SLR88nMFmb",
        "42EqaaybZBnosXyujPiBdb",
        "466n/o8mBBJ6pHBiw5iG22",
        "4aHWU7YVpHaITxR0tJn8N/",
        "57ETvrvmdFdags/MfMec6Z",
        "5d1o9RyJJNErZCUL13Alcy",
        "5fgPVBk7lJ8b2CUGd5U6Cz",
        "63cRRRQNlLS7UZ3Pm9JzPM",
        "64r7t2lqFG0YiXSf4205Sw",
        "6eEvTWWtJMNbdbQFyG6+IX",
        "7dA/6GrORLjpgHCPJ14TNJ",
        "7eqWRsGoJHn6kWlJQZccfD",
        "82ucOYNbhBeo6am9snUC8z",
        "8fLmRwNjxKhqZbcBExbzRH",
        "9atYEzkWJJ3JWewO7X4nQ4",
        "9cKvbBJUFECYnUVLtzmtFQ",
        "b5KhbZ4vJNLYbt6/iExhKi",
        "b7Ocror2dEhbIM22CDld5K",
        "b9E4+/rCVF1rpmABYOIpq9",
        "bbqcWuV2xJEZkziGKib2cL",
        "cak1UanmBD5plEbPUutJTP",
        "cbdS3jbapGv6CNhR8IMTCX",
        "d1foTvwEhKzZYhlAx5ZNEl",
        "d6/shlks1D9a6iBOQhig/A",
        "danDMTKW9EhL4zHY1i44mC",
        "e1ga/2PchKQLmX8+VYkjy8",
        "e16305fu5K1IXnqJ24+OVp",
        "e48UL3gEZIJLKFLYJXFiMn",
        "e6YKkfWq5Fd7B8UmwDF2cJ",
        "f79TY20UZDv6psu9pfi+CM",
        "f86l7qYoVK35QabYKLuzsY",
        "16h1k+5q5O/KpYrJPmPZ9X",
        "1ftzzxY55LtL/A6zcBGz/6",
        "3bVp2ZVfFKFYmCusT0aysz",
        "3dx7qv1BlOqLzpxn7sv4BS",
        "429bTZdQxGWqe8t3oOLj4s",
        "45jY1ImrRNdq0kFGae1W8G",
        "47SwS6qtNNy4jra0TpdRCX",
        "52a2E6U8BFsobGOzsFVarl",
        "55G9rDrn9E1LJgMXzcGhzC",
        "5aiHP6RrlAdISyBEAMkchw",
        "5for0QhKtHsa3VCOmbIfQ1",
        "60ogl5V8hLBI3SQ9fXLltZ",
        "6aSdAC0rhA1YcQozhW2ZTf",
        "7bgEkFWZ9JbYg3NzJmXeJe",
        "7fL+pZku9KcqU2ApBpATvP",
        "81UU33x0xCUJIZgBHQKiDA",
        "a3+HzOqSlKoapnpqCGtzvJ",
        "b4OCVk1t9FqbcGf/ok8YNR",
        "b7FIF+LZdNpYDGznWTfi3d",
        "bfSc3iDCRFT67qeye3vaDL",
        "d0C2woXvdJDZYWGmvuczvA",
        "d3zzEDq29OqJVFzPLxzbug",
        "e8ASXpaMFCfJQO+IrsoOrG",
        "eb6yYkFL1AYLhXbAjKMLEC",
        "eeAc+RTvJMXaMZgdWe/phX",
        "f1nRrEahpGFZ7jM60+Ju+u",
        "15EnM6nlNBKbkRYRQOCtRu",
        "26UNCxXQRNuKKVgWluj0pj",
        "4eGBxwjntNqZPXxbJXw+Rw",
        "a1hU4KvilOoqu/knLeTYVP",
        "bedEeosYlKH76LpEHANtjS",
        "b4rUqjBNZPCrKoJE4puUuQ",
        "0a3Kx5ni1E2YpDczUK42EA",
        "5cO7kybDxGj4ipyMYdRYZB",
        "5f5dyqtRNNxaFmVzYns6FZ",
        "efTxx23nZJYovUVKIFCtIn",
        "c4wX2dXZJPQbHXhcSsWkin",
        "04Jgya8+pBQ4na+nGKL05X",
        "27X1bl9S5HGq5ZpFIYyuPe",
        "2a9qMV5+dJfLbKUJGQVKD5",
        "30+QOgg41PVbBJnKJm6E4/",
        "32BWlUP9RI6ZxyqEZw8zl3",
        "9738rFSPJFVZdzDVt9Gqt0",
        "d1NXF5b5JMp4eWh0YfXwEZ",
        "d1VPtDxVxObLsbmHn48nhn",
        "d6LWJQ6cNBhqRfDKtQ+3mc",
        "f9DZ+Cl9dJ54sd/hBeO8zh",
        "1fk8Od8nZPvYNhIGjYA5D4",
        "77xMpiRudLL4h2PYReSIiu",
        "80kLwClCFKv5IyjaJN75Sv",
        "8cE4ODElBLDqv5KZwAR77H",
        "95ZOoNtzZBtrFVaCR5np5x",
        "faO3YiO5RIwIe2vHzsuqUB",
        "539s4JRiRPZKTJbuJANiO2",
        "82vbglEVBIOpO4jBlp+U3S",
        "e7KAR9Wg9J34g4dL1wpIoc",
        "07Q0C7AIRKfrjYVWD7dDAx",
        "1em6ELX8lGZY1pDKdC3T9m",
        "30PR9p9S1J6KH2hJNnT3wR",
        "48rDDFPJZJqIhz7hizJNPv",
        "59F0DnrlBKm7Q79Tyh9dvU",
        "7cXPVkG3RA3LLb3H0yc0Or",
        "7d+MP8NBpCBp6/kyjz5nES",
        "91IjGpx9VAQK6pDpst/8tj",
        "98KZh8SDFMk4O76+NoQ24n",
        "9fI1TKBVdOyLj36QBSdxBJ",
        "a4GDfDGWRBCpR+heOMSYRT",
        "b9ZRUemThFboIHJTecNTw9",
        "c1x/XjZ51AkbWsRRq1kQ6k",
        "e1OPuty/hPurp/NyExJ/3f",
        "f6mIBMwuZMvrKa1r4TYhNU",
        "842q/rNdVM0rQ0+JhPj0jG",
        "1eMaLSARxJDrK3u9gOC75C",
        "6aI5BI0N5NZavedkWkyyS3",
        "8a6ZEqxmVBa4G4fNjOSXd1",
        "8bGN831pJNB5o9GoaU9oFO",
        "00LXjV9LBGC7ojiU3qCMdz",
        "6cE4AFqttHeKWGopfMHSrl",
        "01oOGaQJtEO78sjuBZpoEz",
        "05S2PQRQJGGZyFDD3qEqqQ",
        "36tWQZoe1DupHp3NWm7Y29",
        "38M7NfJGVK06jlnHR0AB7v",
        "4dyUR9m2RKm65+Ng/msFVE",
        "4eCqj8y5REErMj2dTlP0m6",
        "50CDIwMZtHp5T6cSnwWmyi",
        "58k3+ZGvdLVaZbW/sEmDgi",
        "5a0ocxUR9AJIaE4bKxUPWH",
        "5fcfimzBZEYZ0SocGKHk3P",
        "62n6DnGMhHB7VxJd02y5ea",
        "64ER07tehHn7uRF237Ttxb",
        "67qCQF2cZAO659YUciTjbk",
        "8dvLznEYxC6IRSOP1Lf0DI",
        "9dlTKW7r1Joa90eLHdjSQ4",
        "ba6BEGXHdOb7cI6sSgwaCQ",
        "bdEga3JuhN+JggqNjHx5wu",
        "e8ida7fbRL/qk6nJlkfJuM",
        "2cpbeW5dJAg73zunkTJYRP",
        "2fQ9jH8FBA8bYSM8ZwjGcK",
        "16GRyiFNlIurKdp0DKEn51",
        "9bvaMerUlDyary99mJa6xp",
        "e7/h/OlURJKKCJACBpUaT7",
        "9e/tHsCKZEyLzjADPNCHq1",
        "e7WAH1HMlADbt2wE9xUKxm",
        "08tIrnnYFJYrq0D6/f9c8N",
        "0bMGFJn+VL7ZJnqSMCdvud",
        "24sSY6m3FPUoBMBgDxlJLs",
        "247es2smlBIIiqbroBCNjQ",
        "2cX0Zy4t9IW7TkAV/blTvH",
        "36Z6ehs1JLxofG/DWocqCj",
        "3a2u+UXfJPbaHoxDcpqIlK",
        "42zbyr941AiKxV17ePpfNY",
        "43MIBNGoVNW7AepEptKMah",
        "64G80uc6BF1oPJFcey2sWl",
        "67fzIWLrNLi46ra93/8EXE",
        "6cqsCbl9NGu66gTvu8cYan",
        "73QmaGqZxCnYYw27Q8J6j3",
        "8fWTKVLvVCqqdEqnDyaXKE",
        "98+bWXu3RE3ZQV+Lnp8xXW",
        "9bO+4dt1FDm4PVMvvqrcgG",
        "9cJkJ8179AfbFVvPjM9PQq",
        "9cgwrbm11OSpLQ7vT04iIP",
        "a3cGs6qWREqIOryAgo5prx",
        "a95u9VCqNJs5ZRd9WX4dyu",
        "b5yM2Tl7dFyI40QF3xnLGh",
        "d0El21k6BJ0pERIv373MYr",
        "e5K4fcfMRKY6lv3VwMH5R/",
        "18CXxi/WVLOYgpcY19KVlN",
        "1cJTk8EWtJCL+QSdq3Tsa2",
        "48gWv+LExDSqHloarkAwqQ",
        "5bVI+UtwVExahfYDY8itcY",
        "7aqhpmik9OmJAABNEjU2hY",
        "902U8UDSNMpLU1PK23Fo1x",
        "a81gvWUuxDoIYOMAL/SKQN",
        "acjInrIiRGF7iEfrAshrM/",
        "b8ed0dLSZCyYxTvFmlhjrC",
        "c0GKoPeEhAJ6dg/NUKor/k",
        "d7WLpNWcdGGp5+l3GMCwj9",
        "d8sy+E9gRP8abG8RvRdqYi",
        "d85aIAAY1ARqzqHalwVw4A",
        "d91rcfi4ZCfrLsnU3NaIqG",
        "e5ys2aBphGT6/PSoZLRFql",
        "e75KBCzudEb4uM17TR3JBd",
        "ectyIkNeVM3LBKUlOui4BF",
        "f1xjc4wAlJILLN/oJ1Ju5X",
        "f60MLn7bdOjZzgpWY/XyhI",
        "faJkoU+5BML4lGj7LthrYM",
        "fdsdIAqQpP+r05iihkcMyl"
    ],
    "md5AssetsMap": {
        "01/01253e92.json": "3b660",
        "02/022f62f27.json": "aac1f",
        "02/026e49340.json": "cdd78",
        "02/02bbe3181.json": "bee01",
        "03/03e47ed6.json": "d1149",
        "04/044738c47.json": "8d40a",
        "04/04515c98e.json": "b172a",
        "05/05670e58a.json": "04fb2",
        "06/064f848f2.json": "f6bba",
        "06/067c3fa18.json": "4a53a",
        "07/07617dde3.json": "36904",
        "08/08c86ade3.json": "ccce6",
        "08/08d24b90b.json": "4bbe4",
        "09/091128195.json": "54fa0",
        "09/091fe0a1c.json": "e06de",
        "09/09ba18894.json": "a9113",
        "09/09f78cad8.json": "aed69",
        "0a/0a6bb64f3.json": "19cbd",
        "0b/0b78af307.json": "ca8a8",
        "0c/0c837bb54.json": "9f2fc",
        "0d/0d00493e3.json": "cc54d",
        "0d/0d7da1969.json": "897c5",
        "0d/0d88271f5.json": "7d05f",
        "0d/0db5f6eb3.json": "6c501",
        "0e/0e5d7cbf3.json": "eb604",
        "0e/0e6d2fc24.json": "e33e0",
        "0e/0eacd064e.json": "d0b31",
        "0f/0f281f1f9.json": "2c026",
        "0f/0fbd1a5b5.json": "5d7ba",
        "5e/5e9435b7-de3e-4d66-8afd-9ed044d5dba9.json": "faee3",
        "61/614549ea-3670-413b-92b7-515120609b7f.json": "3c59f",
        "79/798c7088-e498-4fc1-aaf1-722ff83ec239.json": "b36c9",
        "7a/7a914bf0-ebb9-473f-8f4e-c57b71ccfde7.json": "9c0b6",
        "93/93e5bccd-acc7-44de-9ec6-97a5dcb9dc29.json": "742a1",
        "d3/d3ede69a-541e-4d7f-8f54-6f0d60417505.json": "10150",
        "fd/fdd3d3f1-7b56-4a31-9dd1-e0403cbdf683.json": "3128e",
        "assets/res/fish/ani/ani_1.png": "4ded3",
        "assets/res/fish/ani/ani_2.png": "088f8",
        "assets/res/fish/ani/ani_3.png": "8e053",
        "assets/res/fish/ani/ani_4.png": "43ce4",
        "assets/res/fish/comm_tips_bg.png": "2592d",
        "assets/res/fish/creat_bg.png": "24157",
        "assets/res/fish/Icon/fama_1_1.png": "09ab3",
        "assets/res/fish/Icon/fama_10_1.png": "fa267",
        "assets/res/fish/Icon/fama_2_1.png": "790c0",
        "assets/res/fish/Icon/fama_20_1.png": "0fd27",
        "assets/res/fish/Icon/fama_3_1.png": "49667",
        "assets/res/fish/Icon/fama_4_1.png": "c8dff",
        "assets/res/fish/Icon/fama_5_1.png": "acc0c",
        "assets/res/fish/Icon/fish_10.png": "72c2d",
        "assets/res/fish/Icon/majiang.png": "9e2af",
        "assets/res/fish/Icon/paijiu_10.png": "b6b5d",
        "assets/res/fish/Icon/paijiu_6.png": "b0fbb",
        "assets/res/fish/Image 914.png": "a4ad2",
        "assets/res/fish/Image 916.png": "ce536",
        "assets/res/fish/Image 918.png": "a1611",
        "assets/res/fish/Image 920.png": "98b73",
        "assets/res/fish/Image 922.png": "3bc44",
        "assets/res/fish/Image 924.png": "e65f9",
        "assets/res/fish/Image_x.png": "42f95",
        "assets/res/fish/img_hulu.png": "c04ac",
        "assets/res/fish/img_qian.png": "b9d63",
        "assets/res/fish/img_xia.png": "d1da3",
        "assets/res/hall/hallbg.jpg": "cf8cf",
        "assets/res/hall/lamplight_blue.png": "14e87",
        "assets/res/hall/lamplight_purple.png": "3048a",
        "assets/res/hall/light_big.png": "79e7d",
        "assets/res/hall/light_micro.png": "0c3a6",
        "assets/res/hall/ting_bg2.jpg": "c784f",
        "assets/res/normal/Num/alert.png": "bbd4a",
        "assets/res/normal/Num/alert1.png": "7307b",
        "assets/res/normal/Num/avatar_head.png": "48371",
        "assets/res/normal/Num/bg_input.png": "67dd0",
        "assets/res/normal/Num/bg_red.jpg": "8d63c",
        "assets/res/normal/Num/bg_topline_phb.png": "fb0c2",
        "assets/res/normal/Num/bg_y.png": "2c22c",
        "assets/res/normal/Num/bp_jinkuang_3.png": "a2203",
        "assets/res/normal/Num/bp_jinkuang.png": "b3fef",
        "assets/res/normal/Num/btn_close.png": "b7516",
        "assets/res/normal/Num/btn_game_home.png": "793a9",
        "assets/res/normal/Num/btn_home.png": "793a9",
        "assets/res/normal/Num/btn_yan (1).png": "7a021",
        "assets/res/normal/Num/btn_yan.1.png": "8e7db",
        "assets/res/normal/Num/bull_banker_animate.png": "b49de",
        "assets/res/normal/Num/bull_banker_bg.png": "be5d0",
        "assets/res/normal/Num/card_hand_shadow.png": "97fe1",
        "assets/res/normal/Num/card_hand.png": "cd08c",
        "assets/res/normal/Num/chat_bg.png": "70516",
        "assets/res/normal/Num/di.png": "e5395",
        "assets/res/normal/Num/dizhu_bg.png": "dc3d6",
        "assets/res/normal/Num/DuiGuo.png": "08271",
        "assets/res/normal/Num/DuiKuang.png": "d3fe0",
        "assets/res/normal/Num/game_bg5.png": "8d1c4",
        "assets/res/normal/Num/game-music01.png": "6b30a",
        "assets/res/normal/Num/gb_btn.png": "64cf2",
        "assets/res/normal/Num/goldcoin.png": "8ab3a",
        "assets/res/normal/Num/grxx7_n_1.png": "96961",
        "assets/res/normal/Num/grxx7_n.png": "5c07f",
        "assets/res/normal/Num/guize.png": "14ffe",
        "assets/res/normal/Num/history2.png": "88009",
        "assets/res/normal/Num/hongbao1.png": "8cc7d",
        "assets/res/normal/Num/inroom_btn.png": "7117f",
        "assets/res/normal/Num/jiesuanbang.jpg": "d59c1",
        "assets/res/normal/Num/line_11.jpg": "6584b",
        "assets/res/normal/Num/longhu13_n.png": "9ebb0",
        "assets/res/normal/Num/music_close.png": "e6e91",
        "assets/res/normal/Num/music_open.png": "76067",
        "assets/res/normal/Num/niuniu_10.png": "bb0d6",
        "assets/res/normal/Num/niuniu_6.png": "ffcbe",
        "assets/res/normal/Num/pai_n.png": "4540f",
        "assets/res/normal/Num/ph_n.png": "40b93",
        "assets/res/normal/Num/progress_bg.png": "e85d6",
        "assets/res/normal/Num/progress_con.png": "76af3",
        "assets/res/normal/Num/red_1.jpg": "3ec80",
        "assets/res/normal/Num/room71_n.png": "e7d73",
        "assets/res/normal/Num/room72_s.png": "47482",
        "assets/res/normal/Num/roomCard.png": "cb202",
        "assets/res/normal/Num/scj4_n.png": "2f2c6",
        "assets/res/normal/Num/shop_line.png": "8d867",
        "assets/res/normal/Num/single_white.png": "f4b41",
        "assets/res/normal/Num/sound_close.png": "591c6",
        "assets/res/normal/Num/sound_open.png": "3d66b",
        "assets/res/normal/Num/ting-card.png": "e2d61",
        "assets/res/normal/Num/ting-more.png": "4d3e6",
        "assets/res/normal/Num/xiaoxi.png": "61fde",
        "assets/res/normal/Num/XuanDian.png": "aee9e",
        "assets/res/normal/Num/xzzsxzjb.png": "ae041",
        "assets/res/normal/Num/zhuang.png": "dc33b",
        "assets/res/normal/other/beimi-3.png": "e461d",
        "assets/res/normal/other/UI2.png": "96dcd",
        "assets/res/paijiu/img_0.png": "35181",
        "assets/resources/audios/bg/Audio_Magic_4.mp3": "897c6",
        "assets/resources/audios/bg/background.mp3": "bc248",
        "assets/resources/audios/bg/backmusic.mp3": "89e83",
        "assets/resources/audios/bg/bgMain.mp3": "6a450",
        "assets/resources/audios/bg/game_bg_rapid.mp3": "20e2f",
        "assets/resources/audios/bg/jeton_sound.mp3": "f4387",
        "assets/resources/audios/bg/ReceiveGold1.mp3": "0af5a",
        "assets/resources/audios/bg/shake_dice.mp3": "be137",
        "assets/resources/audios/bg/Sound 137.mp3": "5d05d",
        "assets/resources/audios/bg/Sound 138.mp3": "ad161",
        "assets/resources/audios/bg/spinbutton.mp3": "e68d2",
        "assets/resources/audios/bg/table_background_music.mp3": "388d6",
        "assets/resources/audios/bg/wrslot_add_0.mp3": "a0565",
        "assets/resources/audios/bg/wrslot_add_7.mp3": "4b002",
        "assets/resources/Num/ta.png": "3b6bd",
        "assets/resources/UI/card.png": "85c4d",
        "assets/resources/UI/dianshu.png": "9603c",
        "assets/resources/UI/icon1.png": "e2dcb",
        "assets/resources/UI/icon2.png": "07502",
        "assets/resources/UI/ik2.png": "ab303",
        "assets/resources/UI/lk.png": "03b42",
        "assets/resources/UI/paijiu_img.png": "c410e",
        "assets/resources/voice/man/dianshu_0_0.mp3": "828b3",
        "assets/resources/voice/man/dianshu_0_1.mp3": "d18b4",
        "assets/resources/voice/man/dianshu_0_101.mp3": "b1994",
        "assets/resources/voice/man/dianshu_0_102.mp3": "bc4ee",
        "assets/resources/voice/man/dianshu_0_103.mp3": "e6719",
        "assets/resources/voice/man/dianshu_0_104.mp3": "0d7c0",
        "assets/resources/voice/man/dianshu_0_105.mp3": "90dc5",
        "assets/resources/voice/man/dianshu_0_106.mp3": "46f0a",
        "assets/resources/voice/man/dianshu_0_107.mp3": "f388e",
        "assets/resources/voice/man/dianshu_0_108.mp3": "4986f",
        "assets/resources/voice/man/dianshu_0_109.mp3": "5f2c3",
        "assets/resources/voice/man/dianshu_0_110.mp3": "6c825",
        "assets/resources/voice/man/dianshu_0_111.mp3": "03a1c",
        "assets/resources/voice/man/dianshu_0_112.mp3": "4949f",
        "assets/resources/voice/man/dianshu_0_113.mp3": "bef59",
        "assets/resources/voice/man/dianshu_0_114.mp3": "d82a2",
        "assets/resources/voice/man/dianshu_0_115.mp3": "4619b",
        "assets/resources/voice/man/dianshu_0_116.mp3": "f183c",
        "assets/resources/voice/man/dianshu_0_17.mp3": "81a5a",
        "assets/resources/voice/man/dianshu_0_2.mp3": "97853",
        "assets/resources/voice/man/dianshu_0_27.mp3": "e80db",
        "assets/resources/voice/man/dianshu_0_3.mp3": "1a279",
        "assets/resources/voice/man/dianshu_0_38.mp3": "209b6",
        "assets/resources/voice/man/dianshu_0_4.mp3": "3ffcc",
        "assets/resources/voice/man/dianshu_0_48.mp3": "d6419",
        "assets/resources/voice/man/dianshu_0_5.mp3": "08c79",
        "assets/resources/voice/man/dianshu_0_59.mp3": "1030d",
        "assets/resources/voice/man/dianshu_0_6.mp3": "92f7f",
        "assets/resources/voice/man/dianshu_0_69.mp3": "5fe4d",
        "assets/resources/voice/man/dianshu_0_7.mp3": "827d2",
        "assets/resources/voice/man/dianshu_0_8.mp3": "ad592",
        "assets/resources/voice/man/dianshu_0_9.mp3": "0b953",
        "assets/resources/voice/man/fish_0_1.mp3": "f9c8a",
        "assets/resources/voice/man/fish_0_2.mp3": "1eabc",
        "assets/resources/voice/man/fish_0_3.mp3": "47d9c",
        "assets/resources/voice/man/fish_0_4.mp3": "ad18d",
        "assets/resources/voice/man/fish_0_5.mp3": "c9234",
        "assets/resources/voice/man/fish_0_6.mp3": "9adb6",
        "assets/resources/voice/man/man_look_poper.mp3": "e0157",
        "assets/resources/voice/man/message1_1.mp3": "641be",
        "assets/resources/voice/man/message1_10.mp3": "a5a90",
        "assets/resources/voice/man/message1_11.mp3": "f1025",
        "assets/resources/voice/man/message1_12.mp3": "cd21a",
        "assets/resources/voice/man/message1_13.mp3": "8b0c5",
        "assets/resources/voice/man/message1_2.mp3": "a1239",
        "assets/resources/voice/man/message1_3.mp3": "8bb53",
        "assets/resources/voice/man/message1_4.mp3": "1405d",
        "assets/resources/voice/man/message1_5.mp3": "8aac4",
        "assets/resources/voice/man/message1_6.mp3": "da614",
        "assets/resources/voice/man/message1_7.mp3": "85b6b",
        "assets/resources/voice/man/message1_8.mp3": "dda18",
        "assets/resources/voice/man/message1_9.mp3": "1f1d1",
        "assets/resources/voice/man/multiple1x1.mp3": "737b8",
        "assets/resources/voice/man/multiple1x10.mp3": "2bb33",
        "assets/resources/voice/man/multiple1x2.mp3": "92a14",
        "assets/resources/voice/man/multiple1x3.mp3": "b9d44",
        "assets/resources/voice/man/multiple1x4.mp3": "f49a2",
        "assets/resources/voice/man/multiple1x5.mp3": "5629e",
        "assets/resources/voice/man/niu1_0.mp3": "d8d62",
        "assets/resources/voice/man/niu1_1.mp3": "e97d2",
        "assets/resources/voice/man/niu1_10.mp3": "ddca5",
        "assets/resources/voice/man/niu1_11.mp3": "8257d",
        "assets/resources/voice/man/niu1_12.mp3": "a65ff",
        "assets/resources/voice/man/niu1_13.mp3": "5e8fe",
        "assets/resources/voice/man/niu1_2.mp3": "3bcdf",
        "assets/resources/voice/man/niu1_3.mp3": "1f0f4",
        "assets/resources/voice/man/niu1_4.mp3": "93c89",
        "assets/resources/voice/man/niu1_5.mp3": "914a6",
        "assets/resources/voice/man/niu1_6.mp3": "5d352",
        "assets/resources/voice/man/niu1_7.mp3": "b391c",
        "assets/resources/voice/man/niu1_8.mp3": "80a6e",
        "assets/resources/voice/man/niu1_9.mp3": "5d682",
        "assets/resources/voice/man/nobanker1_0.mp3": "cfac6",
        "assets/resources/voice/man/nobanker1_1.mp3": "6ad78",
        "assets/resources/voice/other/fapai.mp3": "3662d",
        "assets/resources/voice/other/select.mp3": "25553",
        "assets/resources/voice/other/sort.mp3": "9631b",
        "assets/resources/voice/other/Sound 136.mp3": "dd013",
        "assets/resources/voice/other/Sound 139.mp3": "ccc19",
        "assets/resources/voice/other/Sound 142.mp3": "675de",
        "assets/resources/voice/woman/dianshu_0.mp3": "2826a",
        "assets/resources/voice/woman/dianshu_1.mp3": "73fd8",
        "assets/resources/voice/woman/dianshu_101.mp3": "a2dbe",
        "assets/resources/voice/woman/dianshu_102.mp3": "f0feb",
        "assets/resources/voice/woman/dianshu_103.mp3": "de21c",
        "assets/resources/voice/woman/dianshu_104.mp3": "32c51",
        "assets/resources/voice/woman/dianshu_105.mp3": "83952",
        "assets/resources/voice/woman/dianshu_106.mp3": "e755e",
        "assets/resources/voice/woman/dianshu_107.mp3": "ea70d",
        "assets/resources/voice/woman/dianshu_108.mp3": "40a4a",
        "assets/resources/voice/woman/dianshu_109.mp3": "8265e",
        "assets/resources/voice/woman/dianshu_110.mp3": "3f952",
        "assets/resources/voice/woman/dianshu_111.mp3": "4fbb1",
        "assets/resources/voice/woman/dianshu_112.mp3": "55400",
        "assets/resources/voice/woman/dianshu_113.mp3": "2b460",
        "assets/resources/voice/woman/dianshu_114.mp3": "2c315",
        "assets/resources/voice/woman/dianshu_115.mp3": "ffd6a",
        "assets/resources/voice/woman/dianshu_116.mp3": "33371",
        "assets/resources/voice/woman/dianshu_17.mp3": "397ea",
        "assets/resources/voice/woman/dianshu_2.mp3": "a81a2",
        "assets/resources/voice/woman/dianshu_27.mp3": "d56f6",
        "assets/resources/voice/woman/dianshu_3.mp3": "30bdd",
        "assets/resources/voice/woman/dianshu_38.mp3": "93b11",
        "assets/resources/voice/woman/dianshu_4.mp3": "75984",
        "assets/resources/voice/woman/dianshu_48.mp3": "a84f0",
        "assets/resources/voice/woman/dianshu_5.mp3": "ab58b",
        "assets/resources/voice/woman/dianshu_59.mp3": "d4ef5",
        "assets/resources/voice/woman/dianshu_6.mp3": "1252d",
        "assets/resources/voice/woman/dianshu_69.mp3": "7a53d",
        "assets/resources/voice/woman/dianshu_7.mp3": "1dc20",
        "assets/resources/voice/woman/dianshu_8.mp3": "2a8cf",
        "assets/resources/voice/woman/dianshu_9.mp3": "03d0f",
        "assets/resources/voice/woman/fish_1.mp3": "2437e",
        "assets/resources/voice/woman/fish_2.mp3": "19648",
        "assets/resources/voice/woman/fish_3.mp3": "9bcb5",
        "assets/resources/voice/woman/fish_4.mp3": "dcead",
        "assets/resources/voice/woman/fish_5.mp3": "bf2f2",
        "assets/resources/voice/woman/fish_6.mp3": "955e9",
        "assets/resources/voice/woman/message2_1.mp3": "6066d",
        "assets/resources/voice/woman/message2_10.mp3": "16772",
        "assets/resources/voice/woman/message2_11.mp3": "31456",
        "assets/resources/voice/woman/message2_12.mp3": "30fea",
        "assets/resources/voice/woman/message2_13.mp3": "fb758",
        "assets/resources/voice/woman/message2_2.mp3": "50e63",
        "assets/resources/voice/woman/message2_3.mp3": "0a800",
        "assets/resources/voice/woman/message2_4.mp3": "6e912",
        "assets/resources/voice/woman/message2_5.mp3": "d0e9b",
        "assets/resources/voice/woman/message2_6.mp3": "61a6f",
        "assets/resources/voice/woman/message2_7.mp3": "eee58",
        "assets/resources/voice/woman/message2_8.mp3": "4b9be",
        "assets/resources/voice/woman/message2_9.mp3": "6f542",
        "assets/resources/voice/woman/multiple2x1.mp3": "ec222",
        "assets/resources/voice/woman/multiple2x10.mp3": "1a061",
        "assets/resources/voice/woman/multiple2x2.mp3": "780b4",
        "assets/resources/voice/woman/multiple2x3.mp3": "0dc8d",
        "assets/resources/voice/woman/multiple2x4.mp3": "ce9c2",
        "assets/resources/voice/woman/multiple2x5.mp3": "e3907",
        "assets/resources/voice/woman/niu2_0.mp3": "9412e",
        "assets/resources/voice/woman/niu2_1.mp3": "3a13d",
        "assets/resources/voice/woman/niu2_10.mp3": "1f8b1",
        "assets/resources/voice/woman/niu2_11.mp3": "a1202",
        "assets/resources/voice/woman/niu2_12.mp3": "6a191",
        "assets/resources/voice/woman/niu2_13.mp3": "89cc5",
        "assets/resources/voice/woman/niu2_2.mp3": "984b8",
        "assets/resources/voice/woman/niu2_3.mp3": "6ed98",
        "assets/resources/voice/woman/niu2_4.mp3": "f054e",
        "assets/resources/voice/woman/niu2_5.mp3": "3b32d",
        "assets/resources/voice/woman/niu2_6.mp3": "683ac",
        "assets/resources/voice/woman/niu2_7.mp3": "eee15",
        "assets/resources/voice/woman/niu2_8.mp3": "098f4",
        "assets/resources/voice/woman/niu2_9.mp3": "cb3b6",
        "assets/resources/voice/woman/nobanker2_0.mp3": "eec42",
        "assets/resources/voice/woman/nobanker2_1.mp3": "34a4e",
        "assets/resources/voice/woman/woman_look_poper.mp3": "9184f",
        "internal/image/default_panel.png": "cdbc9",
        "internal/image/default_progressbar.png": "69ff9",
        "internal/image/default_scrollbar_bg.png": "d6732",
        "internal/image/default_scrollbar_vertical_bg.png": "4bb41",
        "internal/image/default_scrollbar_vertical.png": "71821",
        "internal/image/default_sprite_splash.png": "cea68"
    }
}